package com.ftn.enums;

public enum NameRole {

	    ROLE_ADMIN,
		ROLE_USER
	
}
