package com.ftn.service;

public class CommunicationRelationshipService {

}
