package com.ftn.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ftn.model.Role;
import com.ftn.model.User;
import com.ftn.repository.UserRepository;

@Service
public class UserServiceImpl {

	public boolean logIn(User user) {
		// TODO Auto-generated method stub
		return false;
	}
	

}

