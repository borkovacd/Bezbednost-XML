package com.ftn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ftn.model.SubjectSoftware;

public interface SubjectSoftwareRepository extends JpaRepository<SubjectSoftware, Long> {

	SubjectSoftware findByCity(String city);
	
	SubjectSoftware findByEmail(String email);

}
